#!/bin/bash

cat /etc/null > ~/.bash_history
history -c
